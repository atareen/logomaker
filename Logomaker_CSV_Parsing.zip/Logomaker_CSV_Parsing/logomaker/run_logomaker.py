from __future__ import division


import sys
sys.path.append('../')
from numpydoc.docscrape import NumpyDocString

from make_logo import make_logo

doc = NumpyDocString(make_logo.__doc__)

doc_dict = {}
valueString=''
for i in range(len(doc.get('Extended Summary'))):

    if len(doc.get('Extended Summary')[i])!=0:
        valueString+=doc.get('Extended Summary')[i]
    else:
        key = valueString.partition(' ')[0]
        value = " ".join(valueString.split())
        #print key ,":",value
        doc_dict[key] = value
        valueString=''


print(doc_dict['fasta_file'])

